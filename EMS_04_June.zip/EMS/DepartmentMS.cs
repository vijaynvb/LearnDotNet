﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS
{
    class DepartmentMS : IDepartment
    {
        Department[] deptList = new Department[100];

        public void createDepartment()
        {
            throw new NotImplementedException();
        }

        public void deleteDepartment(int id)
        {
            throw new NotImplementedException();
        }

        public string getDepartmentDetails(int id)
        {
            throw new NotImplementedException();
        }

        public void updateDepartment()
        {
            throw new NotImplementedException();
        }
    }
}
